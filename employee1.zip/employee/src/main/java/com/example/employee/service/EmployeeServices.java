package com.example.employee.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.employee.model.Employee;
import com.example.employee.repository.EmployeeRepository;

@Service
public class EmployeeServices {

	@Autowired
	EmployeeRepository employeeRepository;

	public Employee saveEmployee(Employee employee) {
		Employee employees = new Employee();
		employees.setName(employee.getName());
		employees.setSalary(employee.getSalary());
		return employeeRepository.save(employees);
	}

}
