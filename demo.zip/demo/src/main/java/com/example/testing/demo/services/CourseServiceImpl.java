package com.example.testing.demo.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.example.testing.demo.Entities.Course;

@Service
public class CourseServiceImpl implements CourseService{

	
	List<Course> list;
	
	public CourseServiceImpl()
	{
		list=new ArrayList<>();
		list.add(new Course(14,"java","core java book"));
		System.out.println(" debug point ");
		list.add(new Course(15,"spring boot","easy to development"));
	}
	@Override
	public List<Course> getCourse() {
	
		return list;
	}
	
	

}
