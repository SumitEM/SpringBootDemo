package com.example.testing.demo.services;

import java.util.List;

import com.example.testing.demo.Entities.Course;

public interface CourseService {

	public List<Course> getCourse(); 
}
